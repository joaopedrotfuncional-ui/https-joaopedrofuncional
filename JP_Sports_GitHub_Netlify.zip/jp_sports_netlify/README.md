# JP Sports — Plataforma de inscrições

Site de inscrições para eventos e treinões da JP Sports, com painel administrativo, integração com Supabase e publicação estática na Netlify.

## Funcionalidades

- Página pública para consultar o evento ativo e realizar inscrições.
- Seleção de distância e pacote, com campos condicionais para tamanho de camisa.
- Registro de inscrições no Supabase por função segura (`register_participant`).
- Painel administrativo em `/admin` para acompanhar inscrições e pagamentos.
- Exportação de inscritos em CSV.
- Configuração de Pix, WhatsApp e link externo de checkout.
- Cadastro e recuperação de senha do administrador pelo próprio site, conforme configuração do Supabase Auth.

## Estrutura

- `index.html`, `styles.css`, `app.js`: interface e lógica do site.
- `config.js`: URL do projeto Supabase e chave pública.
- `schema.sql`: estrutura do banco, políticas de segurança e funções.
- `_redirects`, `netlify.toml`: configuração de publicação e rotas na Netlify.
- `LEIA-ME.txt`: instruções resumidas em português.

## Requisitos

- Projeto no [Supabase](https://supabase.com/).
- Conta na [Netlify](https://www.netlify.com/) para hospedagem.
- Navegador moderno.

Não é necessário instalar dependências nem executar etapa de build. O site é estático.

## Configuração do Supabase

1. Crie um projeto no Supabase.
2. Abra **SQL Editor → New query**.
3. Copie todo o conteúdo de `schema.sql`, cole no editor e execute.
4. Em **Authentication → Providers → Email**, habilite autenticação por e-mail e configure a confirmação de e-mail conforme sua necessidade.
5. Em **Authentication → URL Configuration**, configure a URL pública do site como `Site URL` e inclua `https://SEU-SITE.netlify.app/admin` nas URLs de redirecionamento permitidas.
6. Em **Project Settings → API**, copie a **Project URL** e a chave **anon/public** ou **publishable**.
7. Abra `config.js` e substitua os valores de exemplo pelos dados do seu projeto.

Exemplo de configuração:

```js
window.JP_CONFIG = {
  SUPABASE_URL: "https://SEU-PROJETO.supabase.co",
  SUPABASE_ANON_KEY: "SUA_CHAVE_PUBLICA"
};
```

Use os nomes de propriedades que já estão no arquivo `config.js` do projeto. Não publique credenciais privadas.

### Segurança das chaves

- A chave `anon/public` ou `publishable` é destinada ao uso no navegador, desde que as políticas RLS do banco estejam corretamente configuradas.
- **Nunca** coloque `service_role`, secret key, senha do banco ou tokens privados em `config.js`, no código do navegador ou no GitHub.
- Se uma credencial privada for publicada por engano, revogue-a/rotacione-a imediatamente no painel do serviço.

## Criar o administrador

Depois de configurar o Supabase e publicar o site:

1. Acesse `https://SEU-SITE.netlify.app/admin`.
2. Use a opção **Criar minha senha de administrador**.
3. O fluxo deste pacote é restrito ao e-mail administrativo autorizado no código e nas políticas do banco.
4. Conclua a confirmação enviada por e-mail, se estiver habilitada.
5. Para recuperar o acesso, use **Esqueci minha senha** na tela de administração.

A criação e a recuperação de conta dependem das configurações de autenticação e das URLs permitidas no Supabase.

## Publicar na Netlify

1. Faça o deploy da pasta que contém `index.html` (esta pasta do projeto).
2. Para publicar pelo Netlify Drop, acesse <https://app.netlify.com/drop> e arraste a pasta `jp_sports_netlify`.
3. Para atualizações, publique novamente a pasta após salvar as alterações.
4. Teste a página inicial e a rota `/admin` antes de divulgar o link e receber inscrições reais.

## Testes recomendados antes de usar em um evento

- Verificar se o evento ativo aparece na página inicial.
- Fazer uma inscrição de teste e confirmar que ela é gravada no Supabase.
- Confirmar que visitantes não conseguem consultar a lista completa de inscritos.
- Entrar no painel com o e-mail autorizado.
- Testar alteração de status de pagamento e exportação CSV.
- Testar recuperação de senha e links de confirmação.
- Verificar o fluxo de Pix e o checkout externo, se configurado.

## Licença

Consulte o arquivo [`LICENSE`](LICENSE). Este repositório mantém todos os direitos reservados ao titular indicado na licença; a publicação no GitHub, por si só, não concede autorização para reutilização, redistribuição ou exploração comercial do código.
